//
//  vector.cpp
//  xcode wk08
//
//  Created by Emily Barrera Bravo on 10/30/17.
//  Copyright © 2017 Emily Barrera Bravo. All rights reserved.
//

#include "vector.h"
