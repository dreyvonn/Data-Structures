//
//  main.cpp
//  maze
//
//  Created by Emily Peck on 12/11/17.
//  Copyright © 2017 Emily Peck. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
