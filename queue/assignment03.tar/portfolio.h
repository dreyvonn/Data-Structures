#ifndef PORTFOLIO_H
#define PORTFOLIO_H

#include <iostream>

using namespace custom;
using namespace std;

class portfolio
{
private:
   Dollars proceeds;
   
public:
   portfolio();
   ~portfolio();
   
};

#endif